/Users/karllivesey/.cargo/bin/cargo +stable test --locked --offline --no-default-features --test application --message-format=json -vv -- --test-threads=1 

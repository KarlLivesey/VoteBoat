/usr/bin/python3 /private/tmp/voteboat-mac484-efd383d-JuSJyd/controls.py 

/usr/bin/cmp /private/tmp/voteboat-mac484-efd383d-JuSJyd/logs/cargo.txt /private/tmp/voteboat-mac480-f7b0ef1-mccmJS/logs/cargo.txt 

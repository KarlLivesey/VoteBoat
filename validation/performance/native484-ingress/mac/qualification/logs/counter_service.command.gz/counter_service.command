/Users/karllivesey/.cargo/bin/cargo +stable test --locked --offline --all-features --test counter_service --message-format=json -vv three_ -- --test-threads=1 

/tmp/voteboat-mac415416-8a5840d/measurement-artifacts/upstream/bench --client-workers 1 --server-workers 16 --clients 4096 --batch 4 --operations 131072 --members 3 --warmup-writes 1024 --latency 

["/tmp/voteboat-native414-mac/candidate/artifacts/native_benchmark","/tmp/voteboat-native414-mac/mac-results/native-tcp-w1-t1-candidate","tcp","256","1","--journal-timings"]

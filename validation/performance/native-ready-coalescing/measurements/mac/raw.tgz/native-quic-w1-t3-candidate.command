["/tmp/voteboat-native414-mac/candidate/artifacts/native_benchmark","/tmp/voteboat-native414-mac/mac-results/native-quic-w1-t3-candidate","quic","256","1","--journal-timings"]

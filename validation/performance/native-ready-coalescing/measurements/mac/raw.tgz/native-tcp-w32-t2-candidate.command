["/tmp/voteboat-native414-mac/candidate/artifacts/native_benchmark","/tmp/voteboat-native414-mac/mac-results/native-tcp-w32-t2-candidate","tcp","256","32","--journal-timings"]

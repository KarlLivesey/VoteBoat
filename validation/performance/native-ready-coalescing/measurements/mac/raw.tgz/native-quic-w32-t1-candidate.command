["/tmp/voteboat-native414-mac/candidate/artifacts/native_benchmark","/tmp/voteboat-native414-mac/mac-results/native-quic-w32-t1-candidate","quic","256","32","--journal-timings"]

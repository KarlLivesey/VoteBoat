["/tmp/voteboat-native414-mac/reference/artifacts/native_benchmark","/tmp/voteboat-native414-mac/mac-results/native-tcp-w32-t2-reference","tcp","256","32","--journal-timings"]

["/tmp/voteboat-native414-mac/reference/artifacts/native_benchmark","/tmp/voteboat-native414-mac/mac-results/native-quic-w32-t2-reference","quic","256","32","--journal-timings"]

["/tmp/voteboat-native414-mac/reference/artifacts/native_benchmark","/tmp/voteboat-native414-mac/mac-results/native-quic-w1-t1-reference","quic","256","1","--journal-timings"]

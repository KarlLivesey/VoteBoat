/usr/bin/cmp /private/tmp/voteboat-mac486-dcdcafe-XAunHE/logs/cargo.txt /private/tmp/voteboat-mac480-f7b0ef1-mccmJS/logs/cargo.txt 

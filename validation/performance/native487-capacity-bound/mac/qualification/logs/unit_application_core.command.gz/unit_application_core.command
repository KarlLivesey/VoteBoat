/Users/karllivesey/.cargo/bin/cargo +stable test --locked --offline --no-default-features --lib --message-format=json -vv application:: -- --test-threads=1 

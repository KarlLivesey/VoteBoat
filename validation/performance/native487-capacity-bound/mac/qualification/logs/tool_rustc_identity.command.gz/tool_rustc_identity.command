/usr/bin/cmp /private/tmp/voteboat-mac486-dcdcafe-XAunHE/logs/rustc.txt /private/tmp/voteboat-mac480-f7b0ef1-mccmJS/logs/rustc.txt 

/usr/bin/python3 /private/tmp/voteboat-mac486-dcdcafe-XAunHE/verify-source.py 

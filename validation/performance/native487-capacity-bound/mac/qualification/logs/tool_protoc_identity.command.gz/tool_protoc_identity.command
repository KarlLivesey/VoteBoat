/usr/bin/cmp /private/tmp/voteboat-mac486-dcdcafe-XAunHE/logs/protoc.txt /private/tmp/voteboat-mac480-f7b0ef1-mccmJS/logs/protoc.txt 

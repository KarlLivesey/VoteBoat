/usr/bin/cmp /private/tmp/voteboat-mac486-dcdcafe-XAunHE/logs/tool-sha256.txt /private/tmp/voteboat-mac480-f7b0ef1-mccmJS/logs/tool-sha256.txt 

/Users/karllivesey/.cargo/bin/cargo +stable test --locked --offline --all-features --test application --message-format=json -vv -- --test-threads=1 

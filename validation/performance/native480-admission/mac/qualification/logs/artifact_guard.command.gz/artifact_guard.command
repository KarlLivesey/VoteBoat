/usr/bin/python3 /private/tmp/voteboat-mac480-f7b0ef1-mccmJS/collect-artifacts.py 

/usr/bin/cmp /private/tmp/voteboat-mac480-f7b0ef1-mccmJS/logs/rustc.txt /private/tmp/voteboat-mac476-7e90682-kN01PT/logs/rustc.txt 
